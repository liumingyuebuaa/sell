package com.imooc.dto;

import lombok.Data;

/**
 * @author wuss.
 * @date 2018/12/24 12:57
 */

@Data
public class ProductInfoDTO {
    private String productId;
    private Integer productQuantity;
}
