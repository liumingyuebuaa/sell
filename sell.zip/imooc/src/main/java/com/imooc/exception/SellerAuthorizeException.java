package com.imooc.exception;

public class SellerAuthorizeException extends RuntimeException {

}
