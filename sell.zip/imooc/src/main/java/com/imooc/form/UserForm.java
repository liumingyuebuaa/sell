package com.imooc.form;

import lombok.Data;

@Data
public class UserForm {
    private String username;
    private String password;
}
