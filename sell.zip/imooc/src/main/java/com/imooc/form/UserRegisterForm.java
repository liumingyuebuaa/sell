package com.imooc.form;

import lombok.Data;

@Data
public class UserRegisterForm {
    private String registerUserName;
    private String registerUsePassword;
}
