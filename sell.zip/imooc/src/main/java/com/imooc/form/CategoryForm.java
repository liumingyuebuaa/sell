package com.imooc.form;


import lombok.Data;

@Data
public class CategoryForm {
    private Integer categoryId;
    private String categoryName;
    private Integer categoryType;
}
