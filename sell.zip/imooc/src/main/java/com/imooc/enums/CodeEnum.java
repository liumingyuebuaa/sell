package com.imooc.enums;

/**
 * @author wuss.
 * @date 2018/12/17 18:05
 */
public interface CodeEnum {
    Integer getCode();
}
