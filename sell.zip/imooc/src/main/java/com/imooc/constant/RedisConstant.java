package com.imooc.constant;

public interface RedisConstant {
    String TOKEN_PREFIX = "token_%s";
    Integer EXPIRE = 600;
}
