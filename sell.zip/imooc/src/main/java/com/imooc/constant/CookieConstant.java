package com.imooc.constant;

public interface CookieConstant {
    String TOKEN = "token";
    Integer expire = 600;
}
