package com.imooc.config;

public class UserConfig {
    public static String key = "xUHdKxzVCbsgVIwTnc1jtpWn";
}
